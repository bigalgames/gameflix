XMB Dot-art Theme
====================


Most icons are made by "Yoshi-kun", a Japanese author, from his website:
http://yspixel.jpn.org/icon/index.html

You can find his collection in the src folder, resized to 256x256 to avoid any kind of filtering happenning in the menu.

The other ones are made by Tatsuya79, some are just slightly altered version of Yoshi-kun ones or 
from various sources.

Ideally they should be drawn in 32x32 pixels then resized to 256x256.

Icons not covered yet are taken from the Monochrome theme.

### Theme Font
 * This theme uses the [M+ P Type-1 Regular](http://mplus-fonts.osdn.jp/design.html#mplus_p1) typeface by the [M+ Fonts Project](http://mplus-fonts.osdn.jp/) covered under the [Free License](http://mplus-fonts.osdn.jp/about-en.html#license).
