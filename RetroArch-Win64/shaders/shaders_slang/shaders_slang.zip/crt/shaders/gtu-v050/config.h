#pragma parameter compositeConnection "Composite Connection Enable" 0.0 0.0 1.0 1.0

#define FIXNUM 6